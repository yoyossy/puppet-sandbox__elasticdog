# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Melang::Application.config.secret_token = 'dd8e7dada4fad788d0e8c9c06881ea6b2f8675320411a9bef44c0b9c32b0c7eb6da203c33ff13986dd67e7ceff5f8447b114e6fec62dddeaa81cebe60010b118'
